#include "girassol.h"
#include <iostream>

using namespace std;


namespace girassol{
void exibirEspecificacao(){

    cout << "\nGirassol dos Montes Distantes" << "\nCapaz de gerar 5 níveis de nectar e saciar 3 níveis de fome";    

}

void polinizar(abelha& abelha){
	abelha.floresPolinizadas += 1;
}

void coletarNectar(abelha& abelha){
	if (abelha.florFavorita == "Girassol dos Montes Distantes"){abelha.nectar += 10;}
	else {abelha.nectar += 5;}
	polinizar(abelha);
}

void comer(joaninha& joaninha){
	
	if (joaninha.florFavorita == "Girassol dos Montes Distantes"){joaninha.plantasComidas += 6;}
	else {joaninha.plantasComidas += 3;}

}
}
