#ifndef LIRIO_H
#define LIRIO_H


#include "../abelhas/abelha.h"
#include "../joaninhas/joaninha.h"

namespace lirio{

    void exibirEspecificacao(void);
	
	void polinizar(abelha& abelha);
	
	void coletarNectar(abelha& abelha);

	void comer(joaninha& joaninha);

}
#endif
