#include "lirio.h"
#include <iostream>

using namespace std;


namespace lirio{
void exibirEspecificacao(){

    cout << "\nLírio do Himalaia" << "\nCapaz de gerar 4 níveis de nectar e saciar 5 níveis de fome";    

}

void polinizar(abelha& abelha){
	abelha.floresPolinizadas += 1;
}

void coletarNectar(abelha& abelha){
	if (abelha.florFavorita == "Lírio do Himalaia"){abelha.nectar += 8;}
	else {abelha.nectar += 4;}
	polinizar(abelha);
}

void comer(joaninha& joaninha){
	
	if (joaninha.florFavorita == "Lírio do Himalaia"){joaninha.plantasComidas += 10;}
	else {joaninha.plantasComidas += 5;}

}
}
