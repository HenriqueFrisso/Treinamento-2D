#ifndef GIRASSOL_H
#define GIRASSOL_H


#include "../abelhas/abelha.h"
#include "../joaninhas/joaninha.h"

namespace girassol{

    void exibirEspecificacao(void);
	
	void polinizar(abelha& abelha);
		
	void coletarNectar(abelha& abelha);

	void comer(joaninha& joaninha);

}
#endif
