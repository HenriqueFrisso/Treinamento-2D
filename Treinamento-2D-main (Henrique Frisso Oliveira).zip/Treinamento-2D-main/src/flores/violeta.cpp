#include "violeta.h"
#include <iostream>

using namespace std;


namespace violeta{
void exibirEspecificacao(){

    cout << "\nVioleta Americana" << "\nCapaz de gerar 3 níveis de nectar e saciar 4 níveis de fome";    

}

void polinizar(abelha& abelha){
	abelha.floresPolinizadas += 1;
}

void coletarNectar(abelha& abelha){
	if (abelha.florFavorita == "Violeta Americana"){abelha.nectar += 6;}
	else {abelha.nectar += 3;}
	polinizar(abelha);
}

void comer(joaninha& joaninha){
	
	if (joaninha.florFavorita == "Violeta Americana"){joaninha.plantasComidas += 8;}
	else {joaninha.plantasComidas += 4;}

}
}
