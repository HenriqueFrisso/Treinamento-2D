#include <iostream>
#include <vector>
#include <ctime>
#include "abelhas/abelha.h"
#include "joaninhas/joaninha.h"
#include "flores/lirio.h"
#include "flores/girassol.h"
#include "flores/violeta.h"
#include "pesticidas/inseticidaFraco.h"
#include "pesticidas/inseticidaForte.h"

#define EXIBIR_DADOS 1
#define EXIBIR_DADOS_INTERMEDIARIOS 0
#define COMPARAR 0
#define DEDETIZAR 1
#define COLETAR_NECTAR 1
#define PRODUZIR_MEL 1
#define COMER 1
#define MORRER_DE_FOME 1



int gerarAleatorio(int min, int max){
	int n;
	unsigned seed = time(0);
    n = ((rand() % max) + min);
    return (n);
}

int main() {
	
//----------------------------------------------------------------------
					//ABELHAS
//----------------------------------------------------------------------
    abelha* bbb = new abelha;
    abelha* zp = new abelha;

    bbb->nome = "Barry Bee Benson";
    bbb->florFavorita = "Violeta Americana";
    bbb->nectar = 3;
    bbb->nectarParaMel = 4;
    bbb->floresPolinizadas = 0;
    bbb->mel = 0;
    bbb->viva = true;

    zp->nome = "Zé Picada";
    zp->florFavorita = "Lírio do Himalaia";
    zp->nectar = 0;
    zp->nectarParaMel = 5;
    zp->floresPolinizadas = 0;
    zp->mel = 0;
    zp->viva = true;

#if EXIBIR_DADOS
    infosAbelha::exibirInfos(*bbb);
    infosAbelha::exibirInfos(*zp);
#endif

#if COLETAR_NECTAR
	std::cout << "\nColetando nectar...";
    if(bbb->viva){coletar::coletarNectar(*bbb, gerarAleatorio(1,3), gerarAleatorio(0,2));}
    if(zp->viva){coletar::coletarNectar(*zp, gerarAleatorio(1,3), gerarAleatorio(0,2));}
#endif

#if EXIBIR_DADOS_INTERMEDIARIOS
    infosAbelha::exibirInfos(*bbb);
    infosAbelha::exibirInfos(*zp);
#endif

#if DEDETIZAR
	std::cout << "\nDedetizando jardim...";
    inseticidaForte::dedetizarAbelha(*bbb);
    inseticidaForte::dedetizarAbelha(*zp);
#endif

#if EXIBIR_DADOS_INTERMEDIARIOS
    infosAbelha::exibirInfos(*bbb);
    infosAbelha::exibirInfos(*zp);
#endif

#if PRODUZIR_MEL
	std::cout << "\nProduzindo mel...";
    if(bbb->viva){produzir::produzirMel(*bbb);}
    if(zp->viva){produzir::produzirMel(*zp);}
#endif

#if EXIBIR_DADOS
    std::cout << "\n\nNovos dados...";
    infosAbelha::exibirInfos(*bbb);
    infosAbelha::exibirInfos(*zp);
#endif

#if COMPARAR
    std::cout << "\n\nComparando abelhas...\n";
    compararAbelhas::compararTudo(*bbb, *zp);
#endif
	
	std::cout << "\n";
	
//----------------------------------------------------------------------
					//JOANINHAS
//----------------------------------------------------------------------

	joaninha* francis = new joaninha;
	joaninha* marinette = new joaninha;

	francis->nome = "Francis";
    francis->florFavorita = "Violeta Americana";
    francis->fome = 10;
    francis->plantasComidas = 0;
    francis->viva = true;
    
    marinette->nome = "Marinette Dupain-Cheng";
    marinette->florFavorita = "Girassol dos Montes Distantes";
    marinette->fome = 6;
    marinette->plantasComidas = 0;
    marinette->viva = true;

#if EXIBIR_DADOS
    infosJoaninha::exibirInfos(*francis);
    infosJoaninha::exibirInfos(*marinette);
#endif

#if COMER
	std::cout << "\nComendo...";
    if(francis->viva){comer::comerFlor(*francis, gerarAleatorio(0,2));}
    if(marinette->viva){comer::comerFlor(*marinette, gerarAleatorio(0,2));}
#endif

#if EXIBIR_DADOS_INTERMEDIARIOS
    infosJoaninha::exibirInfos(*francis);
    infosJoaninha::exibirInfos(*marinette);
#endif

#if DEDETIZAR
	std::cout << "\nDedetizando jardim...";
    inseticidaFraco::dedetizarJoaninha(*francis);
    inseticidaFraco::dedetizarJoaninha(*marinette);
#endif

#if EXIBIR_DADOS_INTERMEDIARIOS
    infosJoaninha::exibirInfos(*francis);
    infosJoaninha::exibirInfos(*marinette);
#endif

#if COMER
	std::cout << "\nComendo...";
    if(francis->viva){comer::comerFlor(*francis, gerarAleatorio(0,2));}
    if(marinette->viva){comer::comerFlor(*marinette, gerarAleatorio(0,2));}
#endif

#if EXIBIR_DADOS_INTERMEDIARIOS
    std::cout << "\n\nNovos dados...";
    infosJoaninha::exibirInfos(*francis);
    infosJoaninha::exibirInfos(*marinette);
#endif

#if MORRER_DE_FOME
    std::cout << "\nO inverno chegou...";
    comer::morrerDeFome(*francis);
    comer::morrerDeFome(*marinette);
#endif

#if EXIBIR_DADOS
    infosJoaninha::exibirInfos(*francis);
    infosJoaninha::exibirInfos(*marinette);
#endif

#if COMPARAR
    std::cout << "\n\nComparando joaninhas...\n";
    compararJoaninhas::compararTudo(*francis, *marinette);
#endif
	
	std::cout << "\n";



    return 0;
}
