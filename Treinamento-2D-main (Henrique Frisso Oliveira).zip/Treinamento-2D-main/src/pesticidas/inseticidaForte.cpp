#include "inseticidaForte.h"
#include <iostream>
#include <ctime>

using namespace std;

namespace inseticidaForte{
void exibirEspecificacao(){

    cout << "\nInseticida Dona Maria" << "\n70% de eficácia contra abelhas e 100% de eficácia contra joaninhas";    

}

void dedetizarAbelha(abelha& abelha){
	unsigned seed = time(0);
    srand(seed);
	if (rand()%100 < 70){abelha.viva = false;}
}
void dedetizarJoaninha(joaninha& joaninha){
	unsigned seed = time(0);
    srand(seed);
	if (rand()%100 < 100){joaninha.viva = false;}
}
}
