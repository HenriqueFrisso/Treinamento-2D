#ifndef INSETICIDA_FRACO_H
#define INSETICIDA_FRACO_H


#include "../abelhas/abelha.h"
#include "../joaninhas/joaninha.h"

namespace inseticidaFraco{

    void exibirEspecificacao(void);
	
	void dedetizarAbelha(abelha& abelha);

	void dedetizarJoaninha(joaninha& joaninha);

}
#endif
