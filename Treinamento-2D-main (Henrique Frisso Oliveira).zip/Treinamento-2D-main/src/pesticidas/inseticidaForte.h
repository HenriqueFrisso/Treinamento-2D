#ifndef INSETICIDA_FORTE_H
#define INSETICIDA_FORTE_H


#include "../abelhas/abelha.h"
#include "../joaninhas/joaninha.h"

namespace inseticidaForte{

    void exibirEspecificacao(void);
	
	void dedetizarAbelha(abelha& abelha);

	void dedetizarJoaninha(joaninha& joaninha);

}
#endif
