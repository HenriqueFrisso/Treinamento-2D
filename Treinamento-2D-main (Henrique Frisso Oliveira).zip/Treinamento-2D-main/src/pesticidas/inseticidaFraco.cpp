#include "inseticidaFraco.h"
#include <iostream>
#include <ctime>

using namespace std;


namespace inseticidaFraco{
void exibirEspecificacao(){

    cout << "\nInseticida Seu João" << "\n30% de eficácia contra abelhas e 60% de eficácia contra joaninhas";    

}

void dedetizarAbelha(abelha& abelha){
	unsigned seed = time(0);
    srand(seed);
	if (rand()%100 < 30){abelha.viva = false;}
}
void dedetizarJoaninha(joaninha& joaninha){
	unsigned seed = time(0);
    srand(seed);
	if (rand()%100 < 60){joaninha.viva = false;}
}
}
