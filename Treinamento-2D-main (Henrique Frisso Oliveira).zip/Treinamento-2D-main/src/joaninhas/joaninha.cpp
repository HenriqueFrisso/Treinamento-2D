#include "joaninha.h"
#include "../flores/violeta.h"
#include "../flores/girassol.h"
#include "../flores/lirio.h"


using namespace std;


namespace infosJoaninha{
void exibirInfos(joaninha joaninha){

    cout << "\n\nNome: " << joaninha.nome;
    cout << "\nNível de fome: " << joaninha.fome;
    cout << "\nPlantas comidas: " << joaninha.plantasComidas;
    if(joaninha.viva){cout << "\n" << joaninha.nome << " está vivo(a).";}
    else{cout << "\n" << joaninha.nome << " não está vivo(a).";}
    std::cout << "\n";

}

void exibirQuantoFaltaParaNaoMorrerDeFome(joaninha joaninha){

    cout << "\nAinda falta... " << joaninha.fome - joaninha.plantasComidas << " para não morrer de fome.";

}

void exibirFlorFavorita(joaninha joaninha){
	
	cout << "\nA flor favorita de " << joaninha.nome << " é: " << joaninha.florFavorita;
	
}
}

namespace comer{
void comerFlor(joaninha& joaninha, int flor){
	if (flor == 0){lirio::comer(joaninha);} 
	else if (flor == 1){violeta::comer(joaninha);} 
	else{girassol::comer(joaninha);}
}

void morrerDeFome(joaninha& joaninha){
	if (joaninha.fome > joaninha.plantasComidas){joaninha.viva = false;}
}
}

namespace compararJoaninhas{
void compararFome(joaninha joaninha1, joaninha joaninha2){
	if (joaninha1.fome > joaninha2.fome){
		cout << "\nA joaninha " << joaninha1.nome << " estava mais faminta.";
	} else if(joaninha1.fome < joaninha2.fome){
		cout << "\nA joaninha " << joaninha2.nome << " estava mais faminta.";
	} else{
		cout << "\nAs joaninhas estavam com o mesmo nível de fome.";
	}
}

void compararComida(joaninha joaninha1, joaninha joaninha2){
	if (joaninha1.plantasComidas > joaninha2.plantasComidas){
		cout << "\nA joaninha " << joaninha1.nome << " comeu mais.";
	} else if(joaninha1.plantasComidas < joaninha2.plantasComidas){
		cout << "\nA joaninha " << joaninha2.nome << " comeu mais.";
	} else{
		cout << "\nAs joaninhas comeram a mesma quantidade de plantas.";
	}
}

void compararTudo(joaninha joaninha1, joaninha joaninha2){
	compararFome(joaninha1, joaninha2);
	compararComida(joaninha1, joaninha2);
}
}
