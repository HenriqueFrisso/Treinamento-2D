#ifndef JOANINHA_H
#define JOANINHA_H

#include <iostream>

struct joaninha
{
    std::string nome;
    std::string florFavorita;
    int fome;
    int plantasComidas;
    bool viva;
};

namespace infosJoaninha{

    void exibirInfos(joaninha joaninha);

    void exibirQuantoFaltaDeNectarParaProduzirMel(joaninha joaninha);

	void comerFlor(joaninha joaninha);
		
}

namespace comer{
	
	void comerFlor(joaninha& joaninha, int flor);
	
	void morrerDeFome(joaninha& joaninha);
	
}

namespace compararJoaninhas{
	
	void compararFome(joaninha joaninha1, joaninha joaninha2);
	
	void compararComida(joaninha joaninha1, joaninha joaninha2);
	
	void compararTudo(joaninha joaninha1, joaninha joaninha2);
}

#endif
