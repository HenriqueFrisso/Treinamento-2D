#ifndef ABELHA_H
#define ABELHA_H

#include <iostream>

struct abelha
{
    std::string nome;
    std::string florFavorita;
    int nectar;
    int nectarParaMel;
    int floresPolinizadas;
    int mel;
    bool viva;
};

namespace infosAbelha{

    void exibirInfos(abelha abelha);

    void exibirQuantoFaltaDeNectarParaProduzirMel(abelha abelha);
    
	void exibirFlorFavorita(abelha abelha);

}
namespace coletar{
	
	void coletarNectar(abelha& abelha, int n, int flor);
	
}
namespace produzir{
	
	void produzirMel(abelha& abelha);
	
}

namespace compararAbelhas{
	
	void compararNectar(abelha abelha1, abelha abelha2);
	
	void compararMel(abelha abelha1, abelha abelha2);
	
	void compararFloresPolinizadas(abelha abelha1, abelha abelha2);
	
	void compararTudo(abelha abelha1, abelha abelha2);
}

#endif
