#include "abelha.h"
#include "../flores/violeta.h"
#include "../flores/girassol.h"
#include "../flores/lirio.h"
#include <ctime>

using namespace std;


namespace infosAbelha{
void exibirInfos(abelha abelha){

    cout << "\n\nNome: " << abelha.nome;
    cout << "\nQuantidade de néctar: " << abelha.nectar;
    cout << "\nNéctar para produzir mel: " << abelha.nectarParaMel;
    cout << "\nQuantidade de Flores polinizadas: " << abelha.floresPolinizadas;
    cout << "\nQuantidade de mel: " << abelha.mel;
    if(abelha.viva){cout << "\n" << abelha.nome << " está vivo(a).";}
    else{cout << "\n" << abelha.nome << " não está vivo(a).";}
    cout << "\n";

}

void exibirQuantoFaltaDeNectarParaProduzirMel(abelha abelha){

    cout << "\nAinda falta... " << abelha.nectarParaMel - abelha.nectar << " para produzir mel.";

}

void exibirFlorFavorita(abelha abelha){
	
	cout << "\nA flor favorita de " << abelha.nome << " é: " << abelha.florFavorita;
}
}

namespace coletar{
void coletarNectar(abelha& abelha, int n, int flor){
	
	for (int i = 0; i < n; i++){
		if (flor == 0){lirio::coletarNectar(abelha);} 
		else if (flor == 1){violeta::coletarNectar(abelha);} 
		else{girassol::coletarNectar(abelha);}
	}
}
}

namespace produzir{
void produzirMel(abelha& abelha){

	while(abelha.nectar >= abelha.nectarParaMel){
		abelha.nectar -= abelha.nectarParaMel;
		abelha.mel += 1;
	}
}
}

namespace compararAbelhas{
void compararNectar(abelha abelha1, abelha abelha2){
	if (abelha1.nectar > abelha2.nectar){
		cout << "\nA abelha " << abelha1.nome << " está carregando mais néctar.";
	} else if(abelha1.nectar < abelha2.nectar){
		cout << "\nA abelha " << abelha2.nome << " está carregando mais néctar.";
	} else{
		cout << "\nAs abelhas estão carregando a mesma quantidade de néctar.";
	}
}

void compararMel(abelha abelha1, abelha abelha2){
	if (abelha1.mel > abelha2.mel){
		cout << "\nA abelha " << abelha1.nome << " fabricou mais mel.";
	} else if(abelha1.mel < abelha2.mel){
		cout << "\nA abelha " << abelha2.nome << " fabricou mais mel.";
	} else{
		cout << "\nAs abelhas fabricaram a mesma quantidade de mel.";
	}
}

void compararFloresPolinizadas(abelha abelha1, abelha abelha2){
	if (abelha1.floresPolinizadas > abelha2.floresPolinizadas){
		cout << "\nA abelha " << abelha1.nome << " polinizou mais flores.";
	} else if(abelha1.mel < abelha2.mel){
		cout << "\nA abelha " << abelha2.nome << " polinizou mais flores.";
	} else{
		cout << "\nAs abelhas polinizaram a mesma quantidade de flores.";
	}
}

void compararTudo(abelha abelha1, abelha abelha2){
	compararNectar(abelha1, abelha2);
	compararMel(abelha1, abelha2);
	compararFloresPolinizadas(abelha1, abelha2);
}
}
